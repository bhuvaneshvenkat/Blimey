package com.bhuvi.proj.constructor;

import java.lang.reflect.Constructor;

public interface ConstructorInt {

	Object defInstance();

	Object newInstance(String name);

	Constructor<?> getFastCons(String name);

	 Object instanceTypeOf(Class<?> name,Object obj);
}
