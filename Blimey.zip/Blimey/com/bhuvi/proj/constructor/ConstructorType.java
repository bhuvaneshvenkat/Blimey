package com.bhuvi.proj.constructor;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

import com.bhuvi.proj.classType.ClassType;
import com.bhuvi.proj.constructor.Constructor$Support.types;
import com.bhuvi.proj.param.Param;




public class ConstructorType<T> {

	  final Class<?> rawType;
	  final Class<?>[] parameterTypes;
	  final Type type;
	  final int hashCode;
	  final String name;
	  final Constructor<?> constructor;
	
@SuppressWarnings("hiding")
public <T> ConstructorType(Constructor<T> cons) {
	this.type=cons.getDeclaringClass();
	this.rawType=(Class<?>)this.type;
	this.constructor=cons;
	this.name=cons.getName();
	this.parameterTypes=cons.getParameterTypes();
	this.hashCode=this.type.hashCode();
}



Object newInstance(Object... obj){
	Object ob=null;
		try {
			ob=this.constructor.newInstance(obj);
		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException e) {
			e.printStackTrace();
		}
	
	return ob;
}

public static ConstructorInt generateConstructor(Class<?> rawType2,final Type type2) {
	ConstructorInt coni=null;
	try {
		coni= (ConstructorInt) types.getType(rawType2);
		if(coni==null)
		return	getSpecificConstructor(rawType2,type2);
	} catch (SecurityException | NoSuchMethodException e) {
		return	getSpecificConstructor(rawType2,type2);
	}
	return coni;
}

@SuppressWarnings({ "unchecked", "rawtypes" })
private static ConstructorInt getSpecificConstructor(final Class<?> rawType2,final Type type2) {

	if(Collection.class.isAssignableFrom(rawType2)){
		if(Queue.class.isAssignableFrom(rawType2)){
			try {
				return types.getType( LinkedList.class);
			} catch (SecurityException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if(Deque.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(ArrayDeque.class);
			} catch (SecurityException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		} else if (EnumSet.class.isAssignableFrom(rawType2)) {
			if (type2 instanceof ParameterizedType) {
	              Type elementType = ((ParameterizedType) type2).getActualTypeArguments()[0];
	              if (elementType instanceof Class) {
	            	  try {
						return types.getType(EnumSet.noneOf((Class)elementType).getClass());
					} catch (SecurityException e) {
						e.printStackTrace();
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					}
	              } 
			}
		}else if (SortedSet.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(TreeSet.class);
			} catch (SecurityException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if(Set.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(LinkedHashSet.class);
			} catch (SecurityException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if(List.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(ArrayList.class);
			} catch (SecurityException | NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
	}
	else if(Map.class.isAssignableFrom(rawType2)){
		if(ConcurrentNavigableMap.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(new ConcurrentSkipListMap<Object, Object>().getClass());
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if(ConcurrentMap.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(new ConcurrentHashMap<Object, Object>().getClass());
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if(SortedMap.class.isAssignableFrom(rawType2)){
			try {
				return types.getType(new TreeMap<Object, Object>().getClass());
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else if (type2 instanceof ParameterizedType && !
		(String.class.isAssignableFrom(ClassType.get(((ParameterizedType)type2)
		.getActualTypeArguments()[0]).getRaw()))){
			try {
				return types.getType(new LinkedHashMap<Object, Object>().getClass());
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}else{
			try {
				return types.getType(new HashMap<Object,Object>().getClass());
			} catch (SecurityException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				e.printStackTrace();
			}
		}
	}
	return null;
}



public Constructor<?> getConstructor(){
	return constructor;
}

/*public Constructor<?> getParam(String name){
	if(this.param.get(name)==null)
		return null;
	return null;
}*/

}
