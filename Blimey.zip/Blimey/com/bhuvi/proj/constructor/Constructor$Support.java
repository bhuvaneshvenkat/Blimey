package com.bhuvi.proj.constructor;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Modifier;



public class Constructor$Support<T> implements ConstructorInt {
private final Constructor<?>[] constructors;
private final int count;
private Constructor<?> defaultConstructor;
private Class<?> clazz;

private Constructor$Support(Constructor<?>[] cons,Constructor<?> con){
	this.defaultConstructor=con;
	this.constructors=cons;
	this.count=constructors.length;
}

private Constructor$Support(Class<?> clazz) throws SecurityException, NoSuchMethodException{
	this(clazz.getDeclaredConstructors(),clazz.getConstructor());
	this.clazz=clazz;
}

public static final class types{
	static <T> Constructor$Support<Object> getType(Class<T> clazz) throws SecurityException, NoSuchMethodException{
		if(Modifier.isAbstract(clazz.getModifiers())){
			return null;
		}
		return new Constructor$Support<Object>(clazz);
	}
}


public Constructor<Object> getFastCons(String name){
	int count=this.count-1;
	while(count>-1){
		new ConstructorType<Object>(constructors[count]);
	}
	return null;
}

@Override
public Object newInstance(String name) {
return null;
}

public Object instanceTypeOf(Class<?> name,Object obj){
	Object object=null;
	try {
		object=	new ConstructorType<Object>(this.clazz.getConstructor(name)).newInstance(obj);
	} catch (NoSuchMethodException | SecurityException e) {
		return null;
	}
	return object;
}

@Override
public Object defInstance() {
	Object obj=null;
try {
	obj= defaultConstructor.newInstance();
} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
	e.printStackTrace();
}
return obj;
}


}
