package com.bhuvi.proj;


import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;

import static com.bhuvi.proj.$Traverse$Suuport.checkNull;
import static com.bhuvi.proj.$Traverse$Suuport.getType;
import static com.bhuvi.proj.$Traverse$Suuport.checkArgument;
import static com.bhuvi.proj.$Traverse$Suuport.checkNotPrimitive;
import static com.bhuvi.proj.$Traverse$Suuport.typeToString;



public class TypeWildcard implements WildcardType {
    private final Type upperBound;
    private final Type lowerBound;

    public TypeWildcard(Type[] upperBounds, Type[] lowerBounds) {
      checkArgument(lowerBounds.length <= 1);
      checkArgument(upperBounds.length == 1);

      if (lowerBounds.length == 1) {
        checkNull(lowerBounds[0]);
        checkNotPrimitive(lowerBounds[0]);
        checkArgument(upperBounds[0] == Object.class);
        this.lowerBound = getType(lowerBounds[0]);
        this.upperBound = Object.class;

      } else {
        checkNull(upperBounds[0]);
        checkNotPrimitive(upperBounds[0]);
        this.lowerBound = null;
        this.upperBound = getType(upperBounds[0]);
      }
    }

    public Type[] getUpperBounds() {
      return new Type[] { upperBound };
    }

    public Type[] getLowerBounds() {
      return lowerBound != null ? new Type[] { lowerBound } : null;//EMPTY_TYPE_ARRAY;
    }

    /*@Override public boolean equals(Object other) {
      return other instanceof WildcardType
          && $Gson$Types.equals(this, (WildcardType) other);
    }*/

    @Override public int hashCode() {
      // this equals Arrays.hashCode(getLowerBounds()) ^ Arrays.hashCode(getUpperBounds());
      return (lowerBound != null ? 31 + lowerBound.hashCode() : 1)
          ^ (31 + upperBound.hashCode());
    }

    @Override public String toString() {
      if (lowerBound != null) {
        return "? super " + typeToString(lowerBound);
      } else if (upperBound == Object.class) {
        return "?";
      } else {
        return "? extends " + typeToString(upperBound);
      }
    }

    private static final long serialVersionUID = 0;
  }
