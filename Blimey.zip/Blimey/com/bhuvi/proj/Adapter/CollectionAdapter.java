package com.bhuvi.proj.Adapter;

import java.sql.ResultSet;
import java.util.Collection;

import com.bhuvi.proj.classType.ClassType;


public class CollectionAdapter<E> implements Adapter<E> {
private final ResultSet execute;
private final Adapter<E> adapter;
private final ClassType<E> clazz;
	public CollectionAdapter(ResultSet execute,Adapter<E> adapt, ClassType<E> clazz){
		this.execute=execute;
		this.adapter=adapt;
		this.clazz=clazz;
	}
	
	@SuppressWarnings("unchecked")
	public E read(){
		Collection<E> collection =(Collection<E>) clazz.getInstance(null);
		adapter.next();
		while(adapter.hasNext()){
			try{
			E instance=adapter.read();
			collection.add(instance);
			}catch(Exception e)
			{
				return null;
			}
		}
		return (E) collection;
	}
	
	@Override
	public boolean hasNext() {
			return this.adapter.hasNext();
	
	}

	@Override
	public E next() {
	this.adapter.next();
		return null;
	}

	@Override
	public Class<?> getRaw() {
		return this.adapter.getRaw();
	}


}
