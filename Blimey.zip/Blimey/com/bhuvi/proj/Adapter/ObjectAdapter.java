package com.bhuvi.proj.Adapter;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.bhuvi.proj.PatternMatch;
import com.bhuvi.proj.classType.ClassHolder;
import com.bhuvi.proj.classType.ClassType;
import com.bhuvi.proj.field.FieldType;
import com.bhuvi.proj.generate.ArrayTypeHolder;
import com.bhuvi.proj.generate.TypeHolder;

public class ObjectAdapter<T> implements Adapter<T> {
private final ResultSet execute;
private final ClassType<T> clazz;
private boolean called,executed;
private int count;
	public ObjectAdapter(ResultSet execute, ClassType<T> clazz) {
	this.execute=execute;
	this.clazz=clazz;
	try {
		this.count=execute.getMetaData().getColumnCount();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	@Override
	public boolean hasNext() {
			return !executed;
	}
	@Override
	public T next() {
		try {
			if(!called){
			this.execute.next();
			called=true;
			}
		} catch (SQLException e) {
			try {
				throw new SQLException(e);
			} catch (SQLException e1) {
			
			return null;
			}
			}
		
		return null;
	}
	@Override
	public T read() {
		T instance=clazz.getInstance(null);
		try {
			return looping(instance);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return instance;
	}
	
	public T looping(T obj)throws Exception{
		try{
			if(!called)
				executed=!execute.next();
		ResultSetMetaData rsmd=execute.getMetaData();
		for(int index=1;index<=count;index++){
	process(execute.getObject(index),clazz,rsmd.getColumnLabel(index),obj);
		}
		executed=!execute.next();
		}catch(SQLException e){
			throw new SQLException();
		}
		return obj;
	}
	
	
@SuppressWarnings("unchecked")
private void process(Object colObject,ClassHolder<T> clazztype,String fieldName,T obj) throws Exception{
	if(colObject==null)
		return ;
	
		FieldType<?> ftype= clazztype.getFastFieldByName(fieldName);
		if(ftype==null)
			return ;
		
		 if(ftype.getRaw()==Object.class){
			Field field=ftype.getField();
			field.setAccessible(true);
			try {
				field.set(obj, colObject);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
			
		
		if(colObject instanceof Array){
			Array a=(Array) colObject;
			arrayProcess(a,clazztype,fieldName,obj,ftype);
			return ;
		}
		Object rObj=null;
			String str=colObject.toString();
			Field field=ftype.getField();
			field.setAccessible(true);
			Type type=field.getGenericType();
			String typeName=type.getTypeName();
			int i=typeName.lastIndexOf('.')+1;
			String value=typeName.substring(i);
			if(PatternMatch.matches(value)){
				Class<?> raw=(Class<?>) type;
				if( raw== java.util.Date.class){
					 rObj=TypeHolder.UTILDATE.castObject(str);
				}else if(raw==java.sql.Date.class){
					if(raw==colObject.getClass()){
						 rObj=(T) colObject;
					}else{
						 rObj=(T) TypeHolder.SQLDATE.castObject(str);
					}
				}else if(raw==java.sql.Time.class){
					if(raw==colObject.getClass()){
						 rObj=(T) colObject;
					}else{
						 rObj=(T) TypeHolder.SQLTIME.castObject(str);
					}
				}else if(raw==java.sql.Timestamp.class){
					if(raw==colObject.getClass()){
						 rObj=(T) colObject;
					}else{
						 rObj=(T) TypeHolder.SQLTIMESTAMP.castObject(str);
					}
				}else if(raw==java.time.LocalDateTime.class){
					rObj= (T) TypeHolder.LOCALDATETIME.castObject(str);
				}else if(raw==java.time.LocalDate.class){
					rObj= (T) TypeHolder.LOCALDATE.castObject(str);
				}
			}
		rObj= rObj!=null?rObj:TypeHolder.valueOf(value.toUpperCase())
						.castObject(str);
			
			try {
				field.set(obj, rObj);
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
	}


private void arrayProcess(Array a, ClassHolder<T> clazztype,
		String fieldName, T obj,FieldType<?> ftype) {
	String[] strs=new String[0];
	try {
		strs=(String[]) a.getArray();
	} catch (SQLException e) {
		e.printStackTrace();
	}
	Field field=ftype.getField();
	field.setAccessible(true);
	Type type=field.getGenericType();
	String typeName=type.getTypeName();
	int i=typeName.lastIndexOf('.')+1;
	Object value=ArrayTypeHolder.valueOf(typeName.substring(i,typeName.length()-2).toUpperCase())
				.castObject(strs);
	try {
		field.set(obj, value);
	} catch (IllegalArgumentException e) {
		e.printStackTrace();
	} catch (IllegalAccessException e) {
		e.printStackTrace();
	}
	
}
@Override
public Class<?> getRaw() {
return this.clazz.getRaw();
}
}
