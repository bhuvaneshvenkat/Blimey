package com.bhuvi.proj.Adapter;

import java.sql.ResultSet;

import com.bhuvi.proj.classType.ClassType;

public class MapAdapter<T> implements Adapter<T> {

	public MapAdapter(ResultSet execute, Adapter<T> generate, ClassType<T> clazz) {
		
	}

	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public T next() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public T read() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<?> getRaw() {
		// TODO Auto-generated method stub
		return null;
	}

}
