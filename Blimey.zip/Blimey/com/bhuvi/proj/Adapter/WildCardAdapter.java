package com.bhuvi.proj.Adapter;

import java.lang.reflect.Type;
import java.sql.ResultSet;

import com.bhuvi.proj.classType.ClassType;

public class WildCardAdapter implements Adapter<Object> {
private final ResultSet execute;
private final Type[] upperBounds,lowerBounds;
private final ClassType<Object> clazz;
private final Adapter<Object> adapter;
	

	public WildCardAdapter(ResultSet execute, Adapter<Object> adapt, ClassType<Object> clazz2, Type[] upperBounds,
			Type[] lowerBounds) {
		this.execute=execute;
		this.upperBounds=upperBounds;
		this.lowerBounds=lowerBounds;
		this.clazz=clazz2;
		this.adapter=adapt;
	}

	@Override
	public boolean hasNext() {

		return this.adapter.hasNext();
	}

	@Override
	public Object next() {
		this.adapter.next();
		return null;
	}

	@Override
	public Object read() throws Exception {
		adapter.next();
		Object obj=adapter.read();		
		return obj;
	}

	@Override
	public Class<?> getRaw() {
		return this.adapter.getRaw();
	}

}
