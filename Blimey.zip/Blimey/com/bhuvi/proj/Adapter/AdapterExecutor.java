package com.bhuvi.proj.Adapter;




public class AdapterExecutor<T> {

/*@SuppressWarnings("unchecked")
public <E>	Adapter<E> getCollectionAdapter(ResultSet execute,Adapter<E> adapter){
		return (Adapter<E>) new CollectionAdapter<E>(execute,adapter);
	}

@SuppressWarnings("unchecked")
public Adapter<T> getObjectAdapter(ResultSet execute){
	return (Adapter<T>) new ObjectAdapter<T>(execute);
}

public Adapter<T> getDefaultAdapter(ResultSet execute){
	return (Adapter<T>) new DefaultAdapter<T>(execute);
}
*/
}
