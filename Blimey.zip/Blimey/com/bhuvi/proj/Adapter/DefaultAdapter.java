package com.bhuvi.proj.Adapter;

import java.sql.Array;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.regex.Pattern;

import com.bhuvi.proj.PatternMatch;
import com.bhuvi.proj.classType.ClassHolder;
import com.bhuvi.proj.classType.ClassType;
import com.bhuvi.proj.generate.ArrayTypeHolder;
import com.bhuvi.proj.generate.TypeHolder;

public class DefaultAdapter<T> implements Adapter<T>{
private static ResultSet execute;
private int colCount;
private static int counts=1;
private boolean called,executed;
private final ClassType<T> clazz;
	public DefaultAdapter(ResultSet execute, ClassType<T> clazz) {
		DefaultAdapter.execute=execute;
		try {
			this.colCount=execute.getMetaData().getColumnCount();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		this.clazz=clazz;
	}

	@Override
	public boolean hasNext() {
		int count=colCount-counts+1;
		if(executed)
			return false;
			if(count<=0){
				counts=1;
				try {
					if(!executed)
					executed=!execute.next();
				} catch (SQLException e) {
				try {
					throw new SQLException(e);
				} catch (SQLException e1) {
				
				return false;
				}
				}
				return false;
			}
			return true;
	
	}

	@Override
	public T next() {
		try {
			if(!called){
			execute.next();
			called=true;
			}
		}  catch (SQLException e) {
			try {
				throw new SQLException(e);
			} catch (SQLException e1) {
			
			return null;
			}
			}
		return null;
	}

	@Override
	public T read() throws Exception {
		T instance=clazz.getInstance(null);
		
		try {
			return looping(instance);
		} catch (Exception e) {
			throw new Exception();
		}
		
	}
	@SuppressWarnings("unchecked")
	public T looping(T obj)throws Exception{
		
		try{
		ResultSetMetaData rsmd=execute.getMetaData();
		if(!called)
			execute.next();
	
		return	DefaultProcess(execute.getObject(counts),(ClassHolder<T>)clazz,
					rsmd.getColumnLabel(counts),obj,rsmd.getColumnClassName(counts));

		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			counts++;
		}
		return obj;
	}
	@SuppressWarnings("unchecked")
	private T DefaultProcess(Object colObject, ClassHolder<T> clazztype, 
			String fieldName, T obj,String coltype)throws Exception {
	if(colObject==null)
		return null;
	
		T object=(T) clazztype.getInstanceByName(coltype,colObject);
		if(object!=null){
		return object;
		}else{
			if(colObject instanceof Array){
				Array a=(Array) colObject;
				try {
					String[] strs=(String[]) a.getArray();
					String objName=clazz.getRaw().getName();
					int i=objName.lastIndexOf('.')+1;
					object=	(T) ArrayTypeHolder.valueOf(objName.substring(i,objName.length()-2)
							.toUpperCase())
							.castObject(strs);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				return object;
			}
			String str=colObject.toString();
			String objName=clazz.getRaw().getName();
			int i=objName.lastIndexOf('.')+1;
			String value=objName.substring(i);
			if(/*value.matches("Date|Time|Timestamp|LocalDate|LocalDateTime")*/PatternMatch.matches(value)){
				if(!(colObject instanceof java.sql.Date||colObject instanceof java.sql.Time
						||colObject instanceof java.sql.Timestamp))
					throw new RuntimeException("Date format cannot be cast to Non-Date Format");
				
				Class<?> raw=clazz.getRaw();
				
				if( raw== java.util.Date.class){
					return (T) TypeHolder.UTILDATE.castObject(str);
				}else if(raw==java.sql.Date.class){
					if(raw==colObject.getClass()){
						return (T) colObject;
					}else{
						return (T) TypeHolder.SQLDATE.castObject(str);
					}
				}else if(raw==java.sql.Time.class){
					if(raw==colObject.getClass()){
						return (T) colObject;
					}else{
						return (T) TypeHolder.SQLTIME.castObject(str);
					}
				}else if(raw==java.sql.Timestamp.class){
					if(raw==colObject.getClass()){
						return (T) colObject;
					}else{
						return (T) TypeHolder.SQLTIMESTAMP.castObject(str);
					}
				}else if(raw==java.time.LocalDateTime.class){
					return (T) TypeHolder.LOCALDATETIME.castObject(str);
				}else if(raw==java.time.LocalDate.class){
					return (T) TypeHolder.LOCALDATE.castObject(str);
				}
			}
	
			object=(T) TypeHolder.valueOf(value.toUpperCase())
					.castObject(str);
		}
		return object;
	}

	private boolean checkIfDate(Class<?> raw) {
		
		return false;
	}

	@Override
	public Class<?> getRaw() {
return	this.clazz.getRaw();

	}
}
