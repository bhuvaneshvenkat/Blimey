package com.bhuvi.proj.Adapter;

import java.util.Iterator;


public interface Adapter<T> extends Iterator<T>{
T read() throws Exception;
Class<?> getRaw();
}
