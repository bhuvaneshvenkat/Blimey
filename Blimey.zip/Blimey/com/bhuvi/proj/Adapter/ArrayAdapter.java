package com.bhuvi.proj.Adapter;

import java.lang.reflect.Array;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.bhuvi.proj.Adapter.Adapter;
import com.bhuvi.proj.classType.ClassHolder;
import com.bhuvi.proj.classType.ClassType;


public class ArrayAdapter<T> implements Adapter<T> {
	private final ResultSet execute;
	private final Adapter<T> adapter;
	private final ClassType<T> clazz;
	private final ClassType<T> component;
	public ArrayAdapter(ResultSet execute, Adapter<T> adapt, ClassType<T> clazz,ClassHolder<T> clazztype2) {
		this.execute=execute;
		this.adapter=adapt;
		this.clazz=clazz;
		this.component=(ClassType<T>) clazztype2;
	}

	@Override
	public boolean hasNext() {
		return this.adapter.hasNext();
	}

	@Override
	public T next() {
		this.adapter.next();
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T read() throws Exception {
	List<T> list=new ArrayList<T>();
	adapter.next();
	while(adapter.hasNext()){
		T instance=adapter.read();
		list.add(instance);
	}
	  Object array = Array.newInstance(this.component.getRaw(), list.size());
	    for (int i = 0; i < list.size(); i++) {
	      Array.set(array, i, list.get(i));
	    }
	return (T)array;
	}

	@Override
	public Class<?> getRaw() {
		return this.adapter.getRaw();
	}

}
