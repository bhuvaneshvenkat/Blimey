package com.bhuvi.proj.field;

import java.lang.reflect.Field;

public interface FieldTypeInt {
	public int getCount();
	public Field getField(int fieldCount);
	public Field getFieldByName(String name);
	public Field getFastField(String name);
}
