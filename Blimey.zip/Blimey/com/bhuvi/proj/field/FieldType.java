package com.bhuvi.proj.field;

import java.lang.reflect.Field;
import java.lang.reflect.Type;

import com.bhuvi.proj.$Traverse$Suuport;

import static com.bhuvi.proj.field.FieldType$Support.types;

public class FieldType<T> {
	  final Class<? super Field> rawType;
	  final Type type;
	  final int hashCode;
	  final String name;
	  final Field field;
	  @SuppressWarnings("unchecked")
	public
	FieldType(Field field){
		  
		 this.type=$Traverse$Suuport.checkNull(field.getType());
		 this.rawType=(Class<? super Field>) $Traverse$Suuport.getRawType(this.type);
		 this.hashCode=this.type.hashCode();
		 this.name=field.getName();
		 this.field=field;
	  }
	public static <T> FieldTypeInt generateField(Class<? super T> clazz) {
		return types.getType(clazz);
	}
	
	public Field getField(){
		return field;
	}
	public Class<?> getRaw(){
		return this.rawType;
	}
	public Type getType(){
		return this.type;
	}
}
