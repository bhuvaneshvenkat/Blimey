package com.bhuvi.proj.field;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Column;


public final class FieldType$Support implements FieldTypeInt {
private final Field[] fields;
private Map<String,Field> fastFields,fastAnnotFields;
private final int count;
	private FieldType$Support(Field[] declaredFields) {
		this.fields=declaredFields;
		this.count=declaredFields.length;
		generateFastField();
	}

	private void generateFastField() {
		fastFields=new HashMap<String,Field>();
		fastAnnotFields=new HashMap<String,Field>();
		int count=this.count-1;
		while(count>-1){
			Field field=fields[count--];
			if(field.isAnnotationPresent(Column.class)){
				fastAnnotFields.put(field.getAnnotation(Column.class).name().toUpperCase()
						, field);
			}
		fastFields.put(field.getName().toUpperCase(),field );
		}
	}


	public static final class types{
		static <T> FieldType$Support getType(Class<T> clazz){
			return new FieldType$Support(clazz.getDeclaredFields());
		}
	}

	@Override
	public int getCount() {
		return count;
	}

	@Override
	public Field getField(int fieldCount) {
		return fields[fieldCount];
	}
	
	public Field getFieldByName(String name){
		int count=getCount()-1;
		while(count>=0){
			//System.out.println(fields[count--].getName());
			if(	fields[count].getName().equalsIgnoreCase(name))
				break;
			--count;
		}
		return count<0? null:fields[count];
	}
	
	public Field getFastField(String name){
		Field field=fastFields.get(name);
		if(field==null||!field.getName().equalsIgnoreCase(name))
			return fastAnnotFields.get(name);
		return field;
	}
}
