package com.bhuvi.proj;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternMatch {
private static Pattern p;
	public PatternMatch(){
	p=Pattern.compile("Date|Time|Timestamp|LocalDate|LocalDateTime")	;
	}
	
	public static boolean matches(String input){
		Matcher m = p.matcher(input);
		return m.matches();
	}
}
