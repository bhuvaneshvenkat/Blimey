package com.bhuvi.proj;


import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Arrays;

import static com.bhuvi.proj.$Traverse$Suuport.checkNull;
import static com.bhuvi.proj.$Traverse$Suuport.getType;
import static com.bhuvi.proj.$Traverse$Suuport.checkArgument;
import static com.bhuvi.proj.$Traverse$Suuport.checkNotPrimitive;
import static com.bhuvi.proj.$Traverse$Suuport.typeToString;
import static com.bhuvi.proj.$Traverse$Suuport.hashCodeof;


public class TypeParameterized implements ParameterizedType {
	
	private Type[] typeArguments;
	private Type rawType;
	private Type ownerType;
	private int size=0;

	
    public TypeParameterized(Type ownerType, Type rawType, Type[] typeArguments) {
		  if (rawType instanceof Class<?>) {
		        Class<?> rawTypeAsClass = (Class<?>) rawType;
		        boolean isStaticOrTopLevelClass = Modifier.isStatic(rawTypeAsClass.getModifiers())
		            || rawTypeAsClass.getEnclosingClass() == null;
		        checkArgument(ownerType != null || isStaticOrTopLevelClass);
		      }

		      this.ownerType = ownerType == null ? null : getType(ownerType);
		      this.rawType = getType(rawType);
		      this.typeArguments = typeArguments.clone();
		      for (int t = 0; t < this.typeArguments.length; t++) {
		        checkNull(this.typeArguments[t]);
		       checkNotPrimitive(this.typeArguments[t]);
		        this.typeArguments[t] = getType(this.typeArguments[t]);
		      this.size=this.size+1;
		      }
	}

	public Type[] getActualTypeArguments() {
        return typeArguments.clone();
      }

      public Type getRawType() {
        return rawType;
      }

      public Type getOwnerType() {
        return ownerType;
      }

      @Override public boolean equals(Object other) {
        return other instanceof ParameterizedType;
           /* && $Gson$Types.equals(this, (ParameterizedType) other);*/
      }

      @Override public int hashCode() {
        return Arrays.hashCode(typeArguments)
            ^ rawType.hashCode()
            ^ hashCodeof(ownerType);
      }

 
      @Override public String toString() {
          StringBuilder stringBuilder = new StringBuilder(30 * (typeArguments.length + 1));
          stringBuilder.append(typeToString(rawType));

          if (typeArguments.length == 0) {
            return stringBuilder.toString();
          }

          stringBuilder.append("<").append(typeToString(typeArguments[0]));
          for (int i = 1; i < typeArguments.length; i++) {
            stringBuilder.append(", ").append(typeToString(typeArguments[i]));
          }
          return stringBuilder.append(">").toString();
        }
      
}
