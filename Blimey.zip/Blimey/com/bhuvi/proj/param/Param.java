package com.bhuvi.proj.param;


import java.lang.reflect.Constructor;
import java.lang.reflect.Parameter;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import com.bhuvi.proj.constructor.ConstructorType;

public class Param {
/*	private Type type;
	private Class<?> rawType;*/
	private final Parameter[] parameters;
	private final int count;
	
	public Param(ConstructorType<?> constype){
		Constructor<?> cons=constype.getConstructor();
		this.parameters=cons.getParameters();
		this.count=cons.getParameterCount();
	}
	

	static  Class<?> getParameterizedType(Parameter p){
		 
		return  (Class<?>) p.getParameterizedType();
	}
	
public Parameter get(String name) {
	int count=this.count-1;
	Parameter p=null;
	while(count>-1){
	p=parameters[count--];
	}
	return null;
}
	
}
