package com.bhuvi.proj;

import java.lang.reflect.Type;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bhuvi.proj.classType.ClassHolder;
import com.bhuvi.proj.classType.ClassType;
import com.bhuvi.proj.generate.TypeColumn;
import static com.bhuvi.proj.$Traverse$Suuport.checkDefaultness;

public class RTraverse {
private boolean isDefault=false; 
	@SuppressWarnings("unchecked")
	public <T> T fromResult(ResultSet execute, Class<?> class1) {
		isDefault=checkDefaultness(class1);
		Object obj=(T)fromResult(execute,(Type)class1);
		return (T) obj;
	}

	@SuppressWarnings("unchecked")
	public <T> T fromResult(ResultSet execute, Type classType) {
		if(execute==null||isclosed(execute))
			return null;
		new PatternMatch();
		T target = (T) splitArguments(execute, classType);
		/*if(!isclosed(execute))
			close(execute);*/
		return target;
	}

	 private void close(ResultSet execute) {
		try {
			execute.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	private <T> T splitArguments(ResultSet execute,Type type) {
		ClassHolder<T> clazztype=(ClassType<T>) ClassType.get(type);
		return Generate(execute,clazztype);
	}

	private <T> T Generate(ResultSet execute,ClassHolder<T> clazztype) {
		return new TypeColumn(isDefault,execute).getContent(clazztype);
	}

	private boolean isclosed(ResultSet execute) {
		boolean closed=false;
		try {
			closed=execute.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return closed;
	}
	

}
