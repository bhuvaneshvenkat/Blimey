package com.bhuvi.proj;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.Type;


import static com.bhuvi.proj.$Traverse$Suuport.getType;
import static com.bhuvi.proj.$Traverse$Suuport.typeToString;

public class TypeGenericArray implements GenericArrayType {
    private final Type componentType;

    public TypeGenericArray(Type componentType) {
      this.componentType = getType(componentType);
    }

    public Type getGenericComponentType() {
      return componentType;
    }

   /* @Override public boolean equals(Object o) {
      return o instanceof GenericArrayType
          && $Gson$Types.equals(this, (GenericArrayType) o);
    }
*/
    @Override public int hashCode() {
      return componentType.hashCode();
    }

    @Override public String toString() {
 return typeToString(componentType) + "[]";
    }
  }
