package com.bhuvi.proj.classType;

public class Class$Support<T> implements ClassTypeInt<T> {
private final T obj;

public static <T> Class$Support<T>  createNew(T obj) {
	return (Class$Support<T>) new Class$Support<T>(obj);
}
private Class$Support(T obj){
	this.obj=obj;
}
 public T getObject() {
	return (T)this.obj;
}

}
