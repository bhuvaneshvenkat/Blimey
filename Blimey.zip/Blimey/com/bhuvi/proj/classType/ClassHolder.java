package com.bhuvi.proj.classType;


import java.lang.reflect.Type;


import com.bhuvi.proj.field.FieldType;

public interface ClassHolder<T> {
	
	FieldType<?> getField(int index);
	
	FieldType<?> getFieldByName(String fieldName);

	FieldType<?> getFastFieldByName(String fieldName);

	Object getInstanceByName(String fieldName, Object colObject);

	Class<? super T> getRaw();

	Type getTypes();

}
