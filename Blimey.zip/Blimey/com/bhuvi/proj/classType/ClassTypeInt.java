package com.bhuvi.proj.classType;
public interface ClassTypeInt<T> {
	T getObject();
}
