package com.bhuvi.proj.classType;


import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import com.bhuvi.proj.constructor.ConstructorInt;
import com.bhuvi.proj.constructor.ConstructorType;
import com.bhuvi.proj.field.FieldType;
import com.bhuvi.proj.field.FieldTypeInt;

import static  com.bhuvi.proj.$Traverse$Suuport.checkNull;
import static  com.bhuvi.proj.$Traverse$Suuport.getRawType;
import static  com.bhuvi.proj.$Traverse$Suuport.getType;




public class ClassType<T> implements ClassHolder<T> {
	  private final Class<? super T> rawType;
	  final Type type;
	  final int hashCode;
	 private  ClassTypeInt<?> support;
	  private  FieldTypeInt field;
	  private final ConstructorInt cs;
	  @SuppressWarnings("unchecked")
	  ClassType(Type type) {
		  checkNull(type);
		    this.type = getType(type);
		    this.rawType = (Class<? super T>) getRawType(this.type);
		    this.hashCode = this.type.hashCode();
		    this.field=FieldType.generateField((Class<? super T>)this.rawType);
		    this.cs=checkPrimitive()?	null	:
		    		ConstructorType.generateConstructor((Class<? super T>)this.rawType, type);
		  }

	private boolean checkPrimitive() {
		try{
		return  ((Class<?>) type).isPrimitive();
		}catch(ClassCastException e){
			return false;
		}
	}
	@SuppressWarnings("unchecked")
	public ClassType(){
		  this.type=getSuperclassTypeParameter(getClass());
		  this.rawType=(Class<? super T>) getRawType(this.type);
		  this.hashCode=this.type.hashCode();
		  this.cs=null;
	  }
	  
	 public static ClassType<?> get(Type type) {
		    return new ClassType<Object>(type);
		  }
@SuppressWarnings({ "unchecked" })
 <S> void construct(){
		//Construct cons=new Construct(rawType);
		Class$Support<S> support=(Class$Support<S>) Class$Support.createNew(rawType);
		if(support!=null)
			this.support=support;
	
	return ;
}


  FieldTypeInt generateField(Class<? super T> clazz) {
	this.field=FieldType.generateField(clazz);
	return this.field;
//this.field=(FieldTypeInt) type2;
}
 public FieldType<Object> getField(int fieldCount){
	 return  new FieldType<Object>(field.getField(fieldCount));
 }
 
public FieldType<Object>  getFieldByName(String name){
	Field field1=field.getFieldByName(name);
	if(field1==null)
		return null;
	 return new FieldType<Object>(field1);
 }

public FieldType<Object>  getFastFieldByName(String name){
	Field field1=field.getFastField(name);
	if(field1==null)
		return null;
	 return new FieldType<Object>(field1);
 }
public Object  getInstanceByName(String name,Object obj){
	Class<?> clazz=null;
	try {
		clazz = Class.forName(name);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	if(cs==null){
		return null;
	}
	Object object=cs.instanceTypeOf(clazz,obj);
	
	 return object;
 }


 ClassTypeInt<?> getSupport() {
	return support;
}


@Override
public Class<? super T> getRaw() {
	return rawType;
}


@Override
public Type getTypes() {
	return type;
}


@SuppressWarnings("unchecked")
public <S> T getInstance(Object object) {
	Class$Support<S> support=null;
	if (cs==null){
		return null;
	}
	if(object==null){
 support=(Class$Support<S>) Class$Support.createNew(cs.defInstance());
	}
	if(support!=null){
		this.support=support;
		return (T) support.getObject();
	}
	
	return null;
}


public String toString(){
	return this.type.toString();
}
static Type getSuperclassTypeParameter(Class<?> subclass) {
    Type superclass = subclass.getGenericSuperclass();
    if (superclass instanceof Class) {
      throw new RuntimeException("Missing type parameter.");
    }
    ParameterizedType parameterized = (ParameterizedType) superclass;
    return getType(parameterized.getActualTypeArguments()[0]);
  }
}
