package com.bhuvi.proj;


import java.lang.reflect.Array;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;



public final class $Traverse$Suuport {

	public static Type getType(Type type){
		 if (type instanceof Class) {
		      Class<?> c = (Class<?>) type;
		      return c.isArray() ? new TypeGenericArray(getType(c.getComponentType())) : c;

		    } else if (type instanceof ParameterizedType) {
		      ParameterizedType p = (ParameterizedType) type;
		      /*return new TypeParameterized(p.getOwnerType(),
		          p.getRawType(), p.getActualTypeArguments());*/
		      return p;

		    } else if (type instanceof GenericArrayType) {
		      GenericArrayType g = (GenericArrayType) type;
		     /* return new TypeGenericArray(g.getGenericComponentType());*/
		      return g;

		    } else if (type instanceof WildcardType) {
		      WildcardType w = (WildcardType) type;
		     /* return new TypeWildcard(w.getUpperBounds(), w.getLowerBounds());*/
		      return w;

		    } else {
		      // type is either serializable as-is or unsupported
		      return type;
		    }
	}
	public static  Class<?> getRawType(Type type) {
		if(type instanceof Class<?>)
			return (Class<?>) type;
		else if(type instanceof ParameterizedType){
		      ParameterizedType parameterizedType = (ParameterizedType) type;
		      Type rawType = parameterizedType.getRawType();
		      checkArgument(rawType instanceof Class);
		      return (Class<?>) rawType;

		}else if (type instanceof GenericArrayType) {
		      Type componentType = ((GenericArrayType)type).getGenericComponentType();
		      return Array.newInstance(getRawType(componentType), 0).getClass();

		    } else if (type instanceof TypeVariable) {
		       return Object.class;

		    } else if (type instanceof WildcardType) {
		      return getRawType(((WildcardType) type).getUpperBounds()[0]);

		    } else {
		      String className = type == null ? "null" : type.getClass().getName();
		      throw new IllegalArgumentException("Expected a Class, ParameterizedType, or "
		          + "GenericArrayType, but <" + type + "> is of type " + className);
		    }
	}

	public static <T> T checkNull(T type) {
		 if (type == null) {
		      throw new NullPointerException();
		    }
		    return type;
	}

	  static void checkArgument(boolean condition) {
		    if (!condition) {
		      throw new IllegalArgumentException();
		    }
		  }
	 static void checkNotPrimitive(Type type) {
		    checkArgument(!(type instanceof Class<?>) || !((Class<?>) type).isPrimitive());
		  }
	 public static String typeToString(Type type) {
		    return type instanceof Class ? ((Class<?>) type).getName() : type.toString();
		  }
	 
	  static int hashCodeof(Object o) {
		    return o != null ? o.hashCode() : 0;
		  }
	  public static boolean checkDefaultness(Class<?> class1) {
			if(class1.isPrimitive()){
				return true;
			}
			if(class1.isArray()){
				if(class1.getComponentType().getName().startsWith("java"))
					return true;
				else return false;
			}
			 if(class1.getPackage().getName().startsWith("java"))
					return true;
			 
			return false;
		}
	  public static Type getArrayComponentType(Type array) {
		    return array instanceof GenericArrayType
		        ? ((GenericArrayType) array).getGenericComponentType()
		        : ((Class<?>) array).getComponentType();
		  }
}
