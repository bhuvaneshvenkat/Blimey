package com.bhuvi.proj.generate;

import java.util.Date;

public enum ArrayTypeHolder{
	INT{
		public Object castObject(String[] items){
			int[] results=new int[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Integer.parseInt(items[i]);
			    } catch (NumberFormatException nfe) {
			      nfe.printStackTrace();
			    }
			}
			return results;
		}
	},INTEGER{
		public Object castObject(String[] items){
			int[] results=new int[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Integer.parseInt(items[i]);
			    } catch (NumberFormatException nfe) {
			      nfe.printStackTrace();
			    }
			}
			return results;
		}
	},DOUBLE{
		public Object castObject(String[] items){
			double[] results=new double[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Double.parseDouble(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},BYTE{
		public Object castObject(String[] items){
			byte[] results=new byte[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Byte.parseByte(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},CHAR{
		public Object castObject(String[] items){
			char[] results=new char[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = (char)Integer.parseInt(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},LONG{
		public Object castObject(String[] items){
			long[] results=new long[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Long.parseLong(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},BOOLEAN{
		public Object castObject(String[] items){
			boolean[] results=new boolean[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Boolean.parseBoolean(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},SHORT{
		public Object castObject(String[] items){
			short[] results=new short[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Short.parseShort(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},STRING{
		public Object castObject(String[] items){
			
			return items;
		}
	},FLOAT{
		public Object castObject(String[] items){
			float[] results=new float[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = Float.parseFloat(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},BIGDECIMAL{
		public Object castObject(String[] items){
			java.math.BigDecimal[] results=new java.math.BigDecimal[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = new java.math.BigDecimal(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},BIGINTEGER{
		public Object castObject(String[] items){
			java.math.BigInteger[] results=new java.math.BigInteger[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] = new java.math.BigInteger(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	},UTILDATE{
		public
		Object castObject(String[] items){
			java.util.Date[] results=new java.util.Date[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] =(Date) TypeHolder.UTILDATE.castObject(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
			}
			return results;
		}
	},SQLDATE{
		public
		Object castObject(String[] items){
			java.sql.Date[] results=new java.sql.Date[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] =(java.sql.Date) TypeHolder.SQLDATE.castObject(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
			}
			return results;
		}
	},SQLTIME{
		public
		Object castObject(String[] items){
			java.sql.Time[] results=new java.sql.Time[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] =(java.sql.Time) TypeHolder.SQLTIME.castObject(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
			}
			return results;
		}
	},SQLTIMESTAMP{
		public
		Object castObject(String[] items){
			java.sql.Timestamp[] results=new java.sql.Timestamp[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] =(java.sql.Timestamp) TypeHolder.SQLTIMESTAMP.castObject(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }catch(Exception e){
			    	e.printStackTrace();
			    }
			}
			return results;
		}
	},NUMBER{
		public
		Object castObject(String[] items){
			SomeNumber[] results=new SomeNumber[items.length];
			for (int i = 0; i < items.length; i++) {
			    try {
			        results[i] =new SomeNumber(items[i]);
			    } catch (NumberFormatException nfe) {
			    	nfe.printStackTrace();
			    }
			}
			return results;
		}
	};
	public Object castObject(String[] obj){
		
		return null;
	}
}