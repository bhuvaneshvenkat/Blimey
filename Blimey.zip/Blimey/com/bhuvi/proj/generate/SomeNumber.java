package com.bhuvi.proj.generate;



public class SomeNumber extends Number {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3015508899739442588L;

	private final String value;
	
	public SomeNumber(String obj) {
this.value=obj;
	}

	@Override
	public double doubleValue() {
return Double.parseDouble(value);
	}

	@Override
	public float floatValue() {
		return Float.parseFloat(value);
	}

	@Override
	public int intValue() {
	return Integer.parseInt(value);
	}

	@Override
	public long longValue() {
	return Long.parseLong(value);
	}
public String toString(){
	return value;
	
}
public int hashCode(){
	return value.hashCode();
}

public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj instanceof SomeNumber) {
    	SomeNumber other = (SomeNumber) obj;
      return value == other.value || value.equals(other.value);
    }
    return false;
  }
}
