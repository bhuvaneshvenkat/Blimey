package com.bhuvi.proj.generate;

import static com.bhuvi.proj.$Traverse$Suuport.checkDefaultness;
import static com.bhuvi.proj.$Traverse$Suuport.getType;
import static com.bhuvi.proj.$Traverse$Suuport.getArrayComponentType;

import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;
import java.sql.ResultSet;
import java.util.Collection;
import java.util.Map;

import com.bhuvi.proj.Adapter.Adapter;
import com.bhuvi.proj.Adapter.ArrayAdapter;
import com.bhuvi.proj.Adapter.CollectionAdapter;
import com.bhuvi.proj.Adapter.DefaultAdapter;
import com.bhuvi.proj.Adapter.MapAdapter;
import com.bhuvi.proj.Adapter.ObjectAdapter;
import com.bhuvi.proj.Adapter.WildCardAdapter;
import com.bhuvi.proj.classType.ClassHolder;
import com.bhuvi.proj.classType.ClassType;


public class TypeColumn {
	private static boolean isDefault;
	private  static ResultSet execute;
public TypeColumn(boolean isDefault,ResultSet execute){
	TypeColumn.isDefault=isDefault;
	TypeColumn.execute=execute;
}


public <T> T getContent(ClassHolder<T> clazztype){
	Adapter<T> adapter=generate(clazztype);
	try {
		return adapter.read();
	} catch (Exception e) {
	return null;
	}
}

	@SuppressWarnings("unchecked")
	private
	 static <T> Adapter<T> generate(ClassHolder<T> clazztype) {
		if(clazztype==null)
			return null;
		isDefault=checkDefaultness(clazztype.getRaw());
		ClassType<T> clazz=(ClassType<T>) clazztype;
		Type type=clazz.getTypes();
		if(type instanceof ParameterizedType){
			if(Collection.class.isAssignableFrom(clazz.getRaw())){
				ParameterizedType parameterized = (ParameterizedType) type;
				ClassHolder<T> clazztype2=(ClassType<T>) ClassType.get( 
						getType(parameterized.getActualTypeArguments()[0]));
			return	new CollectionAdapter<T>(execute,generate(clazztype2),clazz);
			}else if(Map.class.isAssignableFrom(clazz.getRaw())){
				ParameterizedType parameterized = (ParameterizedType) type;
				ClassHolder<T> clazztype2=(ClassType<T>) ClassType.get( 
						getType(parameterized.getActualTypeArguments()[0]));
				return	new MapAdapter<T>(execute,generate(clazztype2),clazz);
			}
		}else if(type instanceof GenericArrayType || type instanceof Class && ((Class<?>)type).isArray()){
			ClassHolder<T> clazztype2=(ClassHolder<T>) ClassType.get(getType(getArrayComponentType(type)));
			return new ArrayAdapter<T>(execute,generate(clazztype2),clazz,clazztype2);
		}else if(type instanceof WildcardType){
			WildcardType wildcard = (WildcardType) type;
			ClassHolder<T> clazztype2=null;
			if(wildcard.getLowerBounds().length>0){
				clazztype2=(ClassHolder<T>) ClassType.get(wildcard.getLowerBounds()[0]);
			}else{
				clazztype2=(ClassHolder<T>) ClassType.get(wildcard.getUpperBounds()[0]);
			}
			return (Adapter<T>) new WildCardAdapter(execute,(Adapter<Object>)generate(clazztype2),(ClassType<Object>) clazz
					,wildcard.getUpperBounds(),wildcard.getLowerBounds());
		}else if(type instanceof Class<?>){
			return isDefault?new DefaultAdapter<T>(execute,clazz): new ObjectAdapter<T>(execute,clazz);		
		}
return null;
	}


	
	

}
