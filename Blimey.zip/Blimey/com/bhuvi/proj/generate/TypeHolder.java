package com.bhuvi.proj.generate;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;



public enum TypeHolder {
	INT{
		public Object castObject(String obj)throws Exception{
			return Integer.parseInt(obj);
		}
	},INTEGER{
		public Object castObject(String obj)throws Exception{
			try{
			return Integer.parseInt(obj);
			}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},DOUBLE{
		public Object castObject(String obj)throws Exception{
			try{
			return Double.parseDouble(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},BYTE{
		public Object castObject(String obj)throws Exception{
			try{
				return Byte.parseByte(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},CHAR{
		public Object castObject(String obj)throws Exception{
			try{
			return (char)Integer.parseInt(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},LONG{
		public Object castObject(String obj)throws Exception{
			try{
			return Long.parseLong(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},BOOLEAN{
		public Object castObject(String obj)throws Exception{
			try{
			return Boolean.parseBoolean(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},SHORT{
		public Object castObject(String obj)throws Exception{
			try{
			return Short.parseShort(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},STRING{
		public Object castObject(String obj)throws Exception{
			return String.valueOf(obj);
		}
	},FLOAT{
		public Object castObject(String obj)throws Exception{
			try{
			return Float.parseFloat(obj);
		}catch(NumberFormatException e){
			e.printStackTrace();
			}
			return null;
		}
	},BIGDECIMAL{
		public Object castObject(String obj)throws Exception{
			return new java.math.BigDecimal(obj);
		}
	},BIGINTEGER{
		public Object castObject(String obj)throws Exception{
			return new java.math.BigInteger(obj);
		}
	},UTILDATE{
		public
		Object castObject(String obj)throws Exception{
			 final DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
				try {
					 final long utilDate = format.parse(obj).getTime();
				      return new java.util.Date(utilDate);
				} catch (ParseException e) {
				}
			final DateFormat enUsFormat
		      = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.US);
			final DateFormat localFormat
		      = DateFormat.getDateTimeInstance(DateFormat.DEFAULT, DateFormat.DEFAULT);
			try {
				return localFormat.parse(obj);
			} catch (ParseException e) {
			}
			try {
			      return enUsFormat.parse(obj);
			    } catch (ParseException ignored) {
			    }
			 try {
			    	return ISO8601Utils.parse(obj, new ParsePosition(0));
			    } catch (ParseException e) {
			    }
			 return null;
		}
	},SQLDATE{
		public
		Object castObject(String obj)throws Exception{
			final DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
			try {
				 final long utilDate = format.parse(obj).getTime();
			      return new java.sql.Date(utilDate);
			} catch (ParseException e) {
				return null;
			}
		}
	},SQLTIME{
		public
		Object castObject(String obj)throws Exception{
			final DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			try {
			      java.util.Date date = format.parse(obj);
			      return new java.sql.Time(date.getTime());
			    } catch (ParseException e) {
			     e.printStackTrace();
			    }
			return null;
		}
	},SQLTIMESTAMP{
		public
		Object castObject(String obj)throws Exception{
		  Date date = (Date) TypeHolder.valueOf("UTILDATE").castObject(obj);
          return date != null ? new Timestamp(date.getTime()) : null;
		}
	},LOCALDATETIME{
		public
		Object castObject(String obj)throws Exception{
			final DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			 long utilDate;
			try {
				utilDate = format.parse(obj).getTime();
			return LocalDateTime.ofInstant(Instant.ofEpochSecond(utilDate), TimeZone
			        .getDefault().toZoneId());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			return null;
		}
	},LOCALDATE{
		public
		Object castObject(String obj) throws Exception{
			LocalDateTime dateTime=(LocalDateTime) TypeHolder.LOCALDATETIME.castObject(obj);
			return dateTime.toLocalDate();
		}
	},NUMBER{
		public
		Object castObject(String obj){
			return new SomeNumber(obj);
		}
	},OBJECT{
		public Object castObject(String obj){
			return obj;
		}
	},STRINGBUILDER{
		public Object castObject(String obj){
			return new StringBuilder(obj);
		}
	},STRINGBUFFER{
		public Object castObject(String obj){
			return new StringBuffer(obj);
		}
	};
	public Object castObject(String obj) throws Exception{
		return null;
	}
}


